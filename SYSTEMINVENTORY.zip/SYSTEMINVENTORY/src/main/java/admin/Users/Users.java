
package admin.Users;

import admin.DashboardAdmin;
import admin.DeviceManagement.Devices;
import admin.Records.Records;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import config.DatabaseConnection;
import javax.swing.Timer;

/**
 *
 * @author pagar
 */
public class Users extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Users.class.getName());

    /**
     * Creates new form Users
     */
    public Users() {
        initComponents();
        cleanupExpiredStudents();

new Timer(60 * 60 * 1000, e -> cleanupExpiredStudents()).start();
        loadStudents("");
    }

    
    
private void loadStudents(String search) {
    DefaultTableModel model =
        (DefaultTableModel) UsersTable.getModel();

    model.setRowCount(0);

    String sql =
        "SELECT full_name, student_id, section, username, ban_until " +
        "FROM users " +
        "WHERE LOWER(role) = 'user' " +
        "AND (full_name LIKE ? OR student_id LIKE ? OR section LIKE ?) " +
        "ORDER BY full_name ASC";

    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        String keyword = "%" + search.trim() + "%";

        pst.setString(1, keyword);
        pst.setString(2, keyword);
        pst.setString(3, keyword);

        try (ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {

                java.sql.Timestamp banUntil =
                    rs.getTimestamp("ban_until");

                String accountStatus = "Active";

                if (banUntil != null &&
                    banUntil.after(
                        new java.sql.Timestamp(
                            System.currentTimeMillis()))) {

                    accountStatus = "Banned until " + banUntil;
                }

                model.addRow(new Object[]{
                    rs.getString("full_name"),
                    rs.getString("student_id"),
                    rs.getString("section"),
                    rs.getString("username"),
                    accountStatus
                });
            }
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
            this,
            "Error loading students: " + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}
    
    
private void loadArchivedStudents() {
    DefaultTableModel model =
        (DefaultTableModel) ArchiveTable.getModel();

    model.setRowCount(0);

    String sql = "SELECT student_id, full_name, section, " +
                 "archived_at, delete_after " +
                 "FROM student_archive " +
                 "ORDER BY archived_at DESC";

    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql);
         ResultSet rs = pst.executeQuery()) {

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getString("student_id"),
                rs.getString("full_name"),
                rs.getString("section"),
                rs.getTimestamp("archived_at"),
                rs.getTimestamp("delete_after")
            });
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this,
            "Error loading archived students: " + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE);
    }
}
        
        
private void cleanupExpiredStudents() {
    String sql =
        "UPDATE users u " +
        "JOIN student_archive sa " +
        "ON sa.original_user_id = u.id " +
        "SET u.full_name = CONCAT('Deleted Student ', u.id), " +
        "    u.student_id = CONCAT('DELETED-', u.id), " +
        "    u.section = '', " +
        "    u.username = CONCAT('deleted_', u.id), " +
        "    u.password = '', " +
        "    u.role = 'deleted' " +
        "WHERE u.role = 'archived' " +
        "AND sa.delete_after <= NOW()";

    String deleteArchiveSql =
        "DELETE FROM student_archive " +
        "WHERE delete_after <= NOW()";

    try (Connection conn = DatabaseConnection.getConnection()) {
        conn.setAutoCommit(false);

        try (PreparedStatement updatePst =
                 conn.prepareStatement(sql);
             PreparedStatement deletePst =
                 conn.prepareStatement(deleteArchiveSql)) {

            updatePst.executeUpdate();
            deletePst.executeUpdate();

            conn.commit();

        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(true);
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this,
            "Archive cleanup failed: " + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE);
    }
}


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        UsersTable = new javax.swing.JTable();
        jLabel22 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        SearchTEXT = new javax.swing.JTextField();
        SearchButton = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        UnbanButton = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        ArchiveTable = new javax.swing.JTable();
        RestoreButton = new javax.swing.JButton();
        RefreshArchiveButton = new javax.swing.JButton();
        jLabel26 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new java.awt.CardLayout());

        jPanel16.setBackground(new java.awt.Color(0, 51, 0));

        jPanel17.setBackground(new java.awt.Color(204, 204, 204));

        UsersTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Full Name", "Student ID", "Section", "Username", "Account Status"
            }
        ));
        jScrollPane1.setViewportView(UsersTable);

        jLabel22.setFont(new java.awt.Font("Times New Roman", 3, 36)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(0, 51, 0));
        jLabel22.setText("Student Accounts");

        jLabel21.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        jLabel21.setText("Search Student::");

        SearchButton.setText("Search");
        SearchButton.addActionListener(this::SearchButtonActionPerformed);

        jButton1.setBackground(new java.awt.Color(0, 102, 51));
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("+Add /Sign-Up Student");
        jButton1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.addActionListener(this::jButton1ActionPerformed);

        jButton4.setBackground(new java.awt.Color(0, 102, 51));
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Edit Student");
        jButton4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton4.addActionListener(this::jButton4ActionPerformed);

        jButton2.setBackground(new java.awt.Color(0, 102, 51));
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Delete Student");
        jButton2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton2.addActionListener(this::jButton2ActionPerformed);

        jButton3.setBackground(new java.awt.Color(255, 51, 51));
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Temporary Ban");
        jButton3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton3.addActionListener(this::jButton3ActionPerformed);

        UnbanButton.setBackground(new java.awt.Color(255, 51, 51));
        UnbanButton.setForeground(new java.awt.Color(255, 255, 255));
        UnbanButton.setText("Unban Student");
        UnbanButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        UnbanButton.addActionListener(this::UnbanButtonActionPerformed);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 289, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(31, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel4Layout.createSequentialGroup()
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(UnbanButton, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(15, 15, 15))
                        .addGroup(jPanel4Layout.createSequentialGroup()
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 933, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(24, 24, 24)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(SearchTEXT, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(SearchButton)
                        .addGap(156, 156, 156))))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addComponent(jLabel22)
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(SearchTEXT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SearchButton))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(UnbanButton, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30))
        );

        jLabel23.setFont(new java.awt.Font("Times New Roman", 3, 58)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(0, 51, 0));
        jLabel23.setText("User Management");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 464, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(52, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addComponent(jLabel23)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(9, Short.MAX_VALUE))
        );

        ArchiveTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Student ID", "Full Name", "Section", "Archived At", "Delete After"
            }
        ));
        jScrollPane2.setViewportView(ArchiveTable);

        RestoreButton.setBackground(new java.awt.Color(0, 102, 51));
        RestoreButton.setForeground(new java.awt.Color(255, 255, 255));
        RestoreButton.setText("Restore");
        RestoreButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        RestoreButton.addActionListener(this::RestoreButtonActionPerformed);

        RefreshArchiveButton.setBackground(new java.awt.Color(0, 102, 51));
        RefreshArchiveButton.setForeground(new java.awt.Color(255, 255, 255));
        RefreshArchiveButton.setText("Refresh");
        RefreshArchiveButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        RefreshArchiveButton.addActionListener(this::RefreshArchiveButtonActionPerformed);

        jLabel26.setFont(new java.awt.Font("Times New Roman", 3, 32)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(0, 51, 0));
        jLabel26.setText("Archive Students/Delete Acc");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jLabel26))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 857, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(RestoreButton, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
                            .addComponent(RefreshArchiveButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(63, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel26)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addGap(55, 55, 55))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                        .addComponent(RestoreButton, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(RefreshArchiveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(63, 63, 63))))
        );

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(175, Short.MAX_VALUE))
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(129, Short.MAX_VALUE))
        );

        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jButton5.setText("Dashboard");
        jButton5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton5.addActionListener(this::jButton5ActionPerformed);

        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jButton6.setText("Device");
        jButton6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton6.addActionListener(this::jButton6ActionPerformed);

        jButton7.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jButton7.setText("Users");
        jButton7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jButton8.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jButton8.setText("Records");
        jButton8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton8.setBorderPainted(false);
        jButton8.addActionListener(this::jButton8ActionPerformed);

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGap(109, 109, 109)
                        .addComponent(jLabel1))
                    .addComponent(jButton5, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                    .addComponent(jButton6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 76, Short.MAX_VALUE)
                .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(48, 48, 48))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(95, 95, 95)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 25, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, "card2");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        

    int selectedRow = UsersTable.getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(
            this,
            "Please select a student first.",
            "No Student Selected",
            JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    String studentId =
        UsersTable.getValueAt(selectedRow, 1).toString();

    int confirm = JOptionPane.showConfirmDialog(
        this,
        "Move student " + studentId
            + " to the archive for 7 days?",
        "Confirm Archive",
        JOptionPane.YES_NO_OPTION
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    String archiveSql =
        "INSERT INTO student_archive "
        + "(original_user_id, full_name, student_id, section, "
        + "username, password, role, archived_at, delete_after) "
        + "SELECT id, full_name, student_id, section, username, "
        + "password, role, NOW(), DATE_ADD(NOW(), INTERVAL 7 DAY) "
        + "FROM users WHERE student_id = ? AND LOWER(role) = 'user'";

    String updateSql =
        "UPDATE users SET role = 'archived' "
        + "WHERE student_id = ? AND LOWER(role) = 'user'";

    try (Connection conn = DatabaseConnection.getConnection()) {
        conn.setAutoCommit(false);

        try (PreparedStatement archivePst =
                 conn.prepareStatement(archiveSql);
             PreparedStatement updatePst =
                 conn.prepareStatement(updateSql)) {

            archivePst.setString(1, studentId);

            int archived = archivePst.executeUpdate();

            if (archived != 1) {
                throw new SQLException(
                    "Student was not found or could not be archived."
                );
            }

            updatePst.setString(1, studentId);

            if (updatePst.executeUpdate() != 1) {
                throw new SQLException(
                    "Could not deactivate the student account."
                );
            }

            conn.commit();

            JOptionPane.showMessageDialog(
                this,
                "Student archived successfully for 7 days."
            );

            loadStudents(SearchTEXT.getText());

        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(true);
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
            this,
            "Error archiving student: " + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
    
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        
int selectedRow = UsersTable.getSelectedRow();

if (selectedRow == -1) {
    JOptionPane.showMessageDialog(this,
        "Please select a student first.");
    return;
}

String studentId =
    UsersTable.getValueAt(selectedRow, 1).toString();

String input = JOptionPane.showInputDialog(this,
    "Enter the number of days to ban this student:",
    "Temporary Ban",
    JOptionPane.QUESTION_MESSAGE);

if (input == null) {
    return;
}

int days;

try {
    days = Integer.parseInt(input.trim());

    if (days <= 0) {
        JOptionPane.showMessageDialog(this,
            "Please enter a number greater than zero.");
        return;
    }
} catch (NumberFormatException e) {
    JOptionPane.showMessageDialog(this,
        "Please enter a valid whole number of days.");
    return;
}

int confirm = JOptionPane.showConfirmDialog(this,
    "Ban student " + studentId + " for " + days + " day(s)?",
    "Confirm Temporary Ban",
    JOptionPane.YES_NO_OPTION);

if (confirm != JOptionPane.YES_OPTION) {
    return;
}

String sql =
    "UPDATE users SET ban_until = ? " +
    "WHERE student_id = ? AND LOWER(role) = 'user'";

try (Connection conn = DatabaseConnection.getConnection();
     PreparedStatement pst = conn.prepareStatement(sql)) {

    java.time.LocalDateTime expiry =
        java.time.LocalDateTime.now().plusDays(days);

    pst.setTimestamp(1, java.sql.Timestamp.valueOf(expiry));
    pst.setString(2, studentId);

    int updated = pst.executeUpdate();

    if (updated == 1) {
        JOptionPane.showMessageDialog(this,
            "Student temporarily banned for " + days + " day(s).");
        loadStudents(SearchTEXT.getText());
    } else {
        JOptionPane.showMessageDialog(this,
            "Student account was not found or is not active.");
    }

} catch (SQLException e) {
    JOptionPane.showMessageDialog(this,
        "Error banning student: " + e.getMessage(),
        "Database Error",
        JOptionPane.ERROR_MESSAGE);
}

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
    
    int selectedRow = UsersTable.getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(
            this,
            "Please select a student first.",
            "No Student Selected",
            JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    String studentId =
        UsersTable.getValueAt(selectedRow, 1).toString();

    EditStudent editPanel = new EditStudent(studentId);

    javax.swing.JFrame frame =
        new javax.swing.JFrame("Edit Student");

    frame.setDefaultCloseOperation(
        javax.swing.JFrame.DISPOSE_ON_CLOSE
    );

    frame.setContentPane(editPanel);
    frame.pack();
    frame.setLocationRelativeTo(this);

    // Refresh the student table when the edit window closes
    frame.addWindowListener(new java.awt.event.WindowAdapter() {
        @Override
        public void windowClosed(java.awt.event.WindowEvent e) {
            loadStudents(SearchTEXT.getText());
        }
    });

    frame.setVisible(true);
    
    }//GEN-LAST:event_jButton4ActionPerformed

    private void SearchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchButtonActionPerformed

    loadStudents(SearchTEXT.getText());
    }//GEN-LAST:event_SearchButtonActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
  
    Login.Signup signupPanel = new Login.Signup();

    javax.swing.JFrame frame = new javax.swing.JFrame("Add Student");
    frame.setDefaultCloseOperation(javax.swing.JFrame.DISPOSE_ON_CLOSE);
    frame.setContentPane(signupPanel);
    frame.pack();
    frame.setLocationRelativeTo(this);
    frame.setVisible(true);
    
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        DashboardAdmin dashboard = new DashboardAdmin();
    dashboard.setLocationRelativeTo(this);
    dashboard.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        
        Devices devices = new Devices();
    devices.setLocationRelativeTo(this);
    devices.setVisible(true);
    this.dispose();
    
    }//GEN-LAST:event_jButton6ActionPerformed

    private void RestoreButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RestoreButtonActionPerformed
        
int selectedRow = ArchiveTable.getSelectedRow();

if (selectedRow == -1) {
    JOptionPane.showMessageDialog(this,
        "Please select a student to restore.");
    return;
}

String studentId =
    ArchiveTable.getValueAt(selectedRow, 0).toString();

int confirm = JOptionPane.showConfirmDialog(this,
    "Restore student " + studentId + "?",
    "Confirm Restore",
    JOptionPane.YES_NO_OPTION);

if (confirm != JOptionPane.YES_OPTION) {
    return;
}

String restoreSql =
    "UPDATE users SET role = 'user' " +
    "WHERE student_id = ? AND LOWER(role) = 'archived'";

String deleteArchiveSql =
    "DELETE FROM student_archive WHERE student_id = ?";

try (Connection conn = DatabaseConnection.getConnection()) {
    conn.setAutoCommit(false);

    try {
        int updated;

        try (PreparedStatement pst = conn.prepareStatement(restoreSql)) {
            pst.setString(1, studentId);
            updated = pst.executeUpdate();
        }

        if (updated != 1) {
            throw new SQLException(
                "The archived student account could not be found.");
        }

        try (PreparedStatement pst =
                 conn.prepareStatement(deleteArchiveSql)) {
            pst.setString(1, studentId);

            if (pst.executeUpdate() != 1) {
                throw new SQLException(
                    "The archive record could not be removed.");
            }
        }

        conn.commit();

        JOptionPane.showMessageDialog(this,
            "Student restored successfully!");

        loadArchivedStudents();

    } catch (SQLException e) {
        conn.rollback();
        throw e;
    } finally {
        conn.setAutoCommit(true);
    }

} catch (SQLException e) {
    JOptionPane.showMessageDialog(this,
        "Error restoring student: " + e.getMessage(),
        "Database Error",
        JOptionPane.ERROR_MESSAGE);
}

    }//GEN-LAST:event_RestoreButtonActionPerformed

    private void RefreshArchiveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RefreshArchiveButtonActionPerformed
        loadArchivedStudents();
    }//GEN-LAST:event_RefreshArchiveButtonActionPerformed

    private void UnbanButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UnbanButtonActionPerformed

    int selectedRow = UsersTable.getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(
            this, "Please select a student first.");
        return;
    }

    String studentId =
        UsersTable.getValueAt(selectedRow, 1).toString();

    int confirm = JOptionPane.showConfirmDialog(
        this,
        "Are you sure you want to unban student " + studentId + "?",
        "Confirm Unban",
        JOptionPane.YES_NO_OPTION
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    String sql =
        "UPDATE users SET ban_until = NULL " +
        "WHERE student_id = ? AND LOWER(role) = 'user'";

    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setString(1, studentId);

        int updated = pst.executeUpdate();

        if (updated == 1) {
            JOptionPane.showMessageDialog(
                this, "Student has been unbanned successfully!");

            loadStudents(SearchTEXT.getText());
        } else {
            JOptionPane.showMessageDialog(
                this, "Student account was not found or is not active.");
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
            this,
            "Error unbanning student: " + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_UnbanButtonActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        Records records = new Records();
    records.setLocationRelativeTo(this);
    records.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_jButton8ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Users().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable ArchiveTable;
    private javax.swing.JButton RefreshArchiveButton;
    private javax.swing.JButton RestoreButton;
    private javax.swing.JButton SearchButton;
    private javax.swing.JTextField SearchTEXT;
    private javax.swing.JButton UnbanButton;
    private javax.swing.JTable UsersTable;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
